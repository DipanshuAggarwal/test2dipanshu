module com.example.test2dipanshu {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.test2dipanshu to javafx.fxml;
    exports com.example.test2dipanshu;
}